from django.apps import AppConfig


class AppFormsConfig(AppConfig):
    name = 'app_forms'
